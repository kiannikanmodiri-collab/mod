# Age of Power — canon boundary notes

These notes keep the supplied encyclopedia separate from image-based proposals while the mod grows.

## Confirmed by the creator's supplied material

- Age of Power has historical and modern eras and an Iranian/Persian center, including Persepolis and Achaemenid motifs.
- Kian leads the Zoroastrians. His known design includes a white uniform and round white military cap, Ahura Mazda/Faravahar chest mark, gold gloves, and black-and-gold equipment.
- Nikan leads Bloody Skulls and has a black skull-themed design.
- Shahbaz is an Iranian hero whose known equipment includes a gold mask, sword, and Lion-and-Sun shield.
- Power of Galaxy, formerly Batpowerman, belongs to Powerverse and is outside this mod.
- Confirmed canonical abilities for Kian, Nikan, Shahbaz, and the pictured heroes have not yet been provided.

## Mod labels that remain provisional

The identifiers Lion Warrior, Eagle Vanguard, Red Dragon, Samurai Guardian, Iron Vanguard, Sun Champion, Blue Guardian, Tiger Guardian, and Steel Sentinel are descriptive working labels derived from the supplied images and country motifs. They are not claimed as official character names. Their costumes and kits are editable drafts until the creator confirms their identities and powers.

The image containing Nazi symbols has no confirmed faction or character identity in the supplied encyclopedia; it is therefore not registered in the mod. This avoids inventing a faction and does not prevent adding it later if its Age of Power role is clarified.
