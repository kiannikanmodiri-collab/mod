# Prototype ability rules — Age of Power

**Design draft only:** these mechanics come from visual motifs and are not official character canon. Hold the character core in the main hand; right-click or press the configurable primary key (default **G**) for the primary move. Shift + right-click or the configurable ultimate key (default **H**) fires the ultimate.

## Shared limits

- Each character has a separate, player-saved energy pool capped at 100.
- Primary: 25 energy, 5-second cooldown. Ultimate: 75 energy, 30-second cooldown.
- Energy recovers by 1 point every 2 game ticks (0.1 seconds). An ability cannot activate if its cooldown is running or energy is too low.
- Area attacks only affect living hostile monsters. Direct fire bolts follow the player's aim and disappear when they hit a block; they do not light blocks. Builds and terrain are not targets.
- Effect durations below are in seconds. A radius is measured in blocks from the player. Launch and blink moves are movement abilities, not guaranteed damage.

| Character / kit | Primary | Ultimate | Main limit |
|---|---|---|---|
| Kian | Asha Aegis: hostile pulse radius 5, 4 damage and knockback; resistance 12s, regeneration 8s, absorption 12s | Faravahar Judgment: radius 8, 12 damage and 4s ignition; stronger resistance 25s, regeneration 15s, absorption 25s | Pulse hits nearby monsters; buffs only Kian |
| Lion Warrior | King's Roar: radius 5, 5 damage and knockback; speed 8s, jump 5s | Lionheart Rampage: radius 7, 10 damage and stronger knockback; speed 16s, jump 12s, strength 16s, resistance 12s | Close-range ring; no block damage |
| Nikan | Shadow Veil: blink to a visible hostile within 9 blocks and strike for 7; invisibility 5s, speed 9s | Dread Pulse: visible target within 14 blocks, blink strike for 12; invisibility 8s, speed 15s | If no target is visible, performs a short forward dash |
| Shahbaz | Royal Guard: radius 3.5, 4 damage and knockback; resistance 9s, strength 8s | Sun Shield Sweep: radius 6, 10 damage and 4s ignition; resistance and strength 15s | Monster targets only for the area strike |
| Eagle Vanguard | Aerial Maneuver: forward/upward launch; slow falling 12s, speed 8s | Skystrike: stronger launch; slow falling 20s, speed 15s, strength 11s | Movement and fall control; no direct strike |
| Red Dragon | Dragon Flare: one aimed fire bolt; fire resistance 12s, strength 8s | Ember Burst: three spread fire bolts plus radius-7 strike for 9 damage and 4s ignition; fire resistance 25s, strength 14s | Bolts vanish on blocks to protect terrain |
| Samurai Guardian | Quick Guard: dash and radius-2.5 slash for 5; speed 7s, resistance 5s | Blade Sweep: stronger dash and radius-4.5 slash for 9; speed 12s, resistance 10s | Short reach; no block damage |
| Iron Vanguard | Iron Resolve: radius 3 shockwave for 3.5 damage; resistance 11s, strength 6s | Heavy Strike: radius 6 shockwave for 8 damage and stronger knockback; resistance 20s, strength 12s | Monster targets only for shockwave |
| Sun Champion | Solar Renewal: self speed 7s and regeneration 6s; regeneration for allied teammates within 5 blocks for 4s | Radiant Pulse: self speed 12s and regeneration 11s; allies within 12 blocks regenerate 8s; radius-6 enemy strike for 8 and 4s ignition | Other players are healed only if on the same team |
| Blue Guardian | Blue Aegis: radius 3.5 enemies slowed 4s; resistance 8s, slow falling 6s | Aegis Burst: radius 7 enemies slowed 9s and frozen 5s; radius-6 strike for 8; resistance 14s, slow falling 11s | Slows hostile monsters; freezing is brief |
| Tiger Guardian | Tiger Dash: leap; radius 4 strike for 4; speed 7s, jump 5s | Pouncing Strike: stronger leap; radius 6 strike for 9; speed 12s, jump 9s, strength 10s | Close-range strike |
| Steel Sentinel | Steel Shell: radius 3 impact for 4; resistance 10s, absorption 8s | Heavy Impact: radius 7 impact for 10 and strong knockback; resistance 19s, absorption 16s | Monster targets only for impact |

## Visuals and sound

The prototypes use Minecraft particles and sounds chosen to match each concept. They do not yet have custom animated character models, bespoke sound recordings, or a continuously visible client HUD energy bar. A ten-segment energy bar and cooldown feedback appear in the action bar when the player activates or tries to activate a power; each core also explains its controls in the item tooltip.
