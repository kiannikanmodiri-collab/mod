package com.ageofpower.mod;

import com.ageofpower.mod.content.ModArmor;
import com.ageofpower.mod.content.ModCreativeTabs;
import com.ageofpower.mod.content.ModBlocks;
import com.ageofpower.mod.content.ModItems;
import com.ageofpower.mod.network.ModNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AgeOfPower.MOD_ID)
public final class AgeOfPower {
    public static final String MOD_ID = "ageofpower";

    public AgeOfPower(FMLJavaModLoadingContext context) {
        ModNetwork.register();
        IEventBus modBus = context.getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModArmor.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.ITEMS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
