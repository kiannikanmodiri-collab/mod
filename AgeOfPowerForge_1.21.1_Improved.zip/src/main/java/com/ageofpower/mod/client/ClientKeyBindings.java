package com.ageofpower.mod.client;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = AgeOfPower.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientKeyBindings {
    private static final String CATEGORY = "key.categories.ageofpower";
    static final KeyMapping PRIMARY = new KeyMapping("key.ageofpower.primary",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY);
    static final KeyMapping ULTIMATE = new KeyMapping("key.ageofpower.ultimate",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY);

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(PRIMARY);
        event.register(ULTIMATE);
    }

    private ClientKeyBindings() {}
}
