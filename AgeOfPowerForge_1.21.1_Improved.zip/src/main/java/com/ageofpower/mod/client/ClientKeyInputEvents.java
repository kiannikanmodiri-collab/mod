package com.ageofpower.mod.client;

import com.ageofpower.mod.AgeOfPower;
import com.ageofpower.mod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = AgeOfPower.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientKeyInputEvents {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.screen != null || minecraft.getConnection() == null) return;
        while (ClientKeyBindings.PRIMARY.consumeClick()) {
            ModNetwork.CHANNEL.send(new ModNetwork.AbilityKeyPacket(false), PacketDistributor.SERVER.noArg());
        }
        while (ClientKeyBindings.ULTIMATE.consumeClick()) {
            ModNetwork.CHANNEL.send(new ModNetwork.AbilityKeyPacket(true), PacketDistributor.SERVER.noArg());
        }
    }

    private ClientKeyInputEvents() {}
}
