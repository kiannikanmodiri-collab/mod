package com.ageofpower.mod.content;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, AgeOfPower.MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AgeOfPower.MOD_ID);

    public static final RegistryObject<Block> PERSEPOLIS_SANDSTONE = block("persepolis_sandstone",
            BlockBehaviour.Properties.of().mapColor(MapColor.SAND).strength(2.0F, 6.0F).sound(SoundType.STONE));
    public static final RegistryObject<Block> PERSEPOLIS_CARVED_STONE = block("persepolis_carved_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.SAND).strength(2.5F, 7.0F).sound(SoundType.STONE));
    public static final RegistryObject<Block> PERSIAN_GOLD_INLAY = block("persian_gold_inlay",
            BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).strength(2.0F, 6.0F).sound(SoundType.METAL));

    private static RegistryObject<Block> block(String name, BlockBehaviour.Properties properties) {
        RegistryObject<Block> block = BLOCKS.register(name, () -> new Block(properties));
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    private ModBlocks() {}
}
