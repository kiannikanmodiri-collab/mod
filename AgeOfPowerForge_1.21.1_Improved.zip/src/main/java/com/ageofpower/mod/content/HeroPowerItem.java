package com.ageofpower.mod.content;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.phys.Vec3;
import java.util.List;
import java.util.Locale;

/** Prototype abilities are playable but remain explicitly marked as draft designs. */
public final class HeroPowerItem extends Item {
    public enum Profile {
        KIAN("Kian"), LION("Lion Warrior"), NIKAN("Nikan"), SHAHBAZ("Shahbaz"),
        EAGLE("Eagle Vanguard"), DRAGON("Red Dragon"), SAMURAI("Samurai Guardian"),
        IRON_VANGUARD("Iron Vanguard"), SUN_CHAMPION("Sun Champion"), BLUE_GUARDIAN("Blue Guardian"),
        TIGER("Tiger Guardian"), STEEL_SENTINEL("Steel Sentinel");

        private final String displayName;
        Profile(String displayName) { this.displayName = displayName; }
    }

    private static final int MAX_ENERGY = 100;
    private final Profile profile;

    public HeroPowerItem(Profile profile) {
        super(new Item.Properties().stacksTo(1).fireResistant());
        this.profile = profile;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("item.ageofpower.power_core.primary_hint",
                Component.keybind("key.ageofpower.primary")));
        tooltip.add(Component.translatable("item.ageofpower.power_core.ultimate_hint",
                Component.keybind("key.ageofpower.ultimate")));
        tooltip.add(Component.translatable("item.ageofpower.power_core.energy_hint"));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer serverPlayer) || !(level instanceof ServerLevel serverLevel)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        boolean success = tryActivate(serverPlayer, serverLevel, player.isShiftKeyDown());
        return success ? InteractionResultHolder.consume(stack) : InteractionResultHolder.fail(stack);
    }

    /** Called by a validated server packet when a player presses one of the mod's power keys. */
    public void activateFromKey(ServerPlayer player, boolean ultimate) {
        tryActivate(player, player.serverLevel(), ultimate);
    }

    private boolean tryActivate(ServerPlayer serverPlayer, ServerLevel serverLevel, boolean ultimate) {
        // Use one server-wide clock so dimension switches cannot alter recharge or cooldowns.
        long now = serverPlayer.getServer().overworld().getGameTime();
        String prefix = "ageofpower." + profile.name().toLowerCase(Locale.ROOT) + ".";
        var data = serverPlayer.getPersistentData();
        String energyKey = prefix + "energy";
        String tickKey = prefix + "last_tick";
        String cooldownKey = prefix + (ultimate ? "ultimate_cooldown" : "power_cooldown");
        String clockVersionKey = prefix + "clock_version";

        // Migrate timestamps written by older builds, which used each dimension's local clock.
        if (data.getInt(clockVersionKey) != 1) {
            data.putLong(tickKey, now);
            data.putLong(prefix + "power_cooldown", 0);
            data.putLong(prefix + "ultimate_cooldown", 0);
            data.putInt(clockVersionKey, 1);
        }

        int energy = data.contains(energyKey) ? data.getInt(energyKey) : MAX_ENERGY;
        long lastTick = data.contains(tickKey) ? data.getLong(tickKey) : now;
        long elapsedTicks = Math.max(0, now - lastTick);
        int recovered = (int) (elapsedTicks / 2);
        energy = Math.min(MAX_ENERGY, energy + recovered);
        // Keep fractional ticks so repeated key presses cannot discard recharge progress.
        data.putLong(tickKey, energy == MAX_ENERGY ? now : lastTick + (long) recovered * 2);

        long cooldownUntil = data.getLong(cooldownKey);
        if (now < cooldownUntil) {
            int seconds = (int) Math.ceil((cooldownUntil - now) / 20.0);
            serverPlayer.displayClientMessage(Component.translatable("message.ageofpower.cooldown", seconds,
                    energyBar(energy), energy), true);
            data.putInt(energyKey, energy);
            return false;
        }

        int cost = ultimate ? 75 : 25;
        if (energy < cost) {
            serverPlayer.displayClientMessage(Component.translatable("message.ageofpower.energy_low", energy, cost,
                    energyBar(energy)), true);
            data.putInt(energyKey, energy);
            return false;
        }

        energy -= cost;
        data.putInt(energyKey, energy);
        data.putLong(cooldownKey, now + (ultimate ? 600 : 100));
        activate(serverPlayer, serverLevel, ultimate);
        serverPlayer.displayClientMessage(Component.translatable("message.ageofpower.power_used", profile.displayName,
                ultimate ? "Ultimate" : "Power", energyBar(energy), energy), true);
        return true;
    }

    private static String energyBar(int energy) {
        int filled = Math.max(0, Math.min(10, energy / 10));
        return "|".repeat(filled) + ".".repeat(10 - filled);
    }

    private void activate(ServerPlayer player, ServerLevel level, boolean ultimate) {
        switch (profile) {
            case KIAN -> kian(player, level, ultimate);
            case LION -> lion(player, level, ultimate);
            case NIKAN -> nikan(player, level, ultimate);
            case SHAHBAZ -> shahbaz(player, level, ultimate);
            case EAGLE -> eagle(player, level, ultimate);
            case DRAGON -> dragon(player, level, ultimate);
            case SAMURAI -> samurai(player, level, ultimate);
            case IRON_VANGUARD -> iron(player, level, ultimate);
            case SUN_CHAMPION -> sun(player, level, ultimate);
            case BLUE_GUARDIAN -> blue(player, level, ultimate);
            case TIGER -> tiger(player, level, ultimate);
            case STEEL_SENTINEL -> steel(player, level, ultimate);
        }
    }

    private static void kian(ServerPlayer p, ServerLevel l, boolean ultimate) {
        if (!ultimate) {
            buff(p, MobEffects.DAMAGE_RESISTANCE, 240, 1);
            buff(p, MobEffects.REGENERATION, 160, 1);
            buff(p, MobEffects.ABSORPTION, 240, 2);
            burst(l, p, ParticleTypes.TOTEM_OF_UNDYING, 42, 0.75);
            strikeNearby(l, p, 5.0, 4.0F, 1.2, false);
        } else {
            buff(p, MobEffects.DAMAGE_RESISTANCE, 500, 2);
            buff(p, MobEffects.REGENERATION, 300, 2);
            buff(p, MobEffects.ABSORPTION, 500, 4);
            burst(l, p, ParticleTypes.END_ROD, 100, 0.85);
            strikeNearby(l, p, 8, 12.0F, 1.7, true);
        }
        p.playSound(SoundEvents.BEACON_ACTIVATE, 1.0F, ultimate ? 0.7F : 1.15F);
    }

    private static void lion(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.MOVEMENT_SPEED, ultimate ? 320 : 160, ultimate ? 2 : 1);
        buff(p, MobEffects.JUMP, ultimate ? 240 : 100, ultimate ? 2 : 1);
        if (ultimate) {
            buff(p, MobEffects.DAMAGE_BOOST, 320, 2);
            buff(p, MobEffects.DAMAGE_RESISTANCE, 240, 1);
        }
        burst(l, p, ParticleTypes.CRIT, ultimate ? 90 : 38, 0.8);
        strikeNearby(l, p, ultimate ? 7 : 5, ultimate ? 10.0F : 5.0F, ultimate ? 2.2 : 1.35, false);
        p.playSound(SoundEvents.RAVAGER_ROAR, 1.2F, ultimate ? 0.7F : 1.0F);
    }

    private static void nikan(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.MOVEMENT_SPEED, ultimate ? 300 : 180, ultimate ? 2 : 1);
        buff(p, MobEffects.INVISIBILITY, ultimate ? 160 : 100, 0);
        burst(l, p, ParticleTypes.SMOKE, ultimate ? 80 : 32, 0.7);
        shadowStep(p, l, ultimate);
        p.playSound(SoundEvents.PHANTOM_FLAP, 0.9F, ultimate ? 0.65F : 1.25F);
    }

    private static void shahbaz(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.DAMAGE_RESISTANCE, ultimate ? 300 : 180, ultimate ? 2 : 1);
        buff(p, MobEffects.DAMAGE_BOOST, ultimate ? 300 : 160, ultimate ? 2 : 1);
        burst(l, p, ParticleTypes.CRIT, ultimate ? 75 : 30, 0.65);
        strikeNearby(l, p, ultimate ? 6 : 3.5, ultimate ? 10.0F : 4.0F,
                ultimate ? 1.8 : 0.7, ultimate);
        p.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, ultimate ? 0.75F : 1.0F);
    }

    private static void eagle(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.SLOW_FALLING, ultimate ? 400 : 240, 0);
        buff(p, MobEffects.MOVEMENT_SPEED, ultimate ? 300 : 160, ultimate ? 2 : 1);
        if (ultimate) buff(p, MobEffects.DAMAGE_BOOST, 220, 1);
        launch(p, ultimate ? 1.65 : 1.0, ultimate ? 0.72 : 0.38);
        burst(l, p, ParticleTypes.CLOUD, ultimate ? 75 : 28, 0.6);
        p.playSound(SoundEvents.ELYTRA_FLYING, 1.0F, ultimate ? 0.7F : 1.1F);
    }

    private static void dragon(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.FIRE_RESISTANCE, ultimate ? 500 : 240, 0);
        buff(p, MobEffects.DAMAGE_BOOST, ultimate ? 280 : 160, ultimate ? 2 : 1);
        fireBolt(p, l, ultimate ? 3 : 1);
        burst(l, p, ParticleTypes.FLAME, ultimate ? 110 : 42, 0.8);
        if (ultimate) strikeNearby(l, p, 7, 9.0F, 1.6, true);
        p.playSound(SoundEvents.BLAZE_SHOOT, 1.0F, ultimate ? 0.65F : 1.0F);
    }

    private static void samurai(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.MOVEMENT_SPEED, ultimate ? 240 : 140, ultimate ? 2 : 1);
        buff(p, MobEffects.DAMAGE_RESISTANCE, ultimate ? 200 : 100, ultimate ? 1 : 0);
        launch(p, ultimate ? 1.45 : 1.15, 0.08);
        burst(l, p, ParticleTypes.SWEEP_ATTACK, ultimate ? 60 : 22, 0.5);
        strikeNearby(l, p, ultimate ? 4.5 : 2.5, ultimate ? 9.0F : 5.0F, ultimate ? 1.7 : 1.0, false);
        p.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, ultimate ? 1.3F : 1.65F);
    }

    private static void iron(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.DAMAGE_RESISTANCE, ultimate ? 400 : 220, ultimate ? 2 : 1);
        buff(p, MobEffects.DAMAGE_BOOST, ultimate ? 240 : 120, ultimate ? 2 : 1);
        burst(l, p, ParticleTypes.CRIT, ultimate ? 70 : 26, 0.6);
        strikeNearby(l, p, ultimate ? 6 : 3, ultimate ? 8.0F : 3.5F,
                ultimate ? 1.5 : 0.65, false);
        p.playSound(SoundEvents.ANVIL_LAND, 0.8F, ultimate ? 0.65F : 1.1F);
    }

    private static void sun(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.MOVEMENT_SPEED, ultimate ? 240 : 140, ultimate ? 2 : 1);
        buff(p, MobEffects.REGENERATION, ultimate ? 220 : 120, ultimate ? 1 : 0);
        burst(l, p, ParticleTypes.END_ROD, ultimate ? 80 : 30, 0.65);
        double allyRadius = ultimate ? 12.0 : 5.0;
        for (Player ally : l.getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(allyRadius), Player::isAlive)) {
            if (ally == p || p.isAlliedTo(ally)) {
                buff(ally, MobEffects.REGENERATION, ultimate ? 160 : 80, ultimate ? 1 : 0);
            }
        }
        if (ultimate) strikeNearby(l, p, 6, 8.0F, 1.4, true);
        p.playSound(SoundEvents.BEACON_POWER_SELECT, 0.9F, ultimate ? 0.75F : 1.2F);
    }

    private static void blue(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.DAMAGE_RESISTANCE, ultimate ? 280 : 160, ultimate ? 2 : 1);
        buff(p, MobEffects.SLOW_FALLING, ultimate ? 220 : 120, 0);
        burst(l, p, ParticleTypes.ENCHANT, ultimate ? 80 : 28, 0.65);
        for (Monster target : l.getEntitiesOfClass(Monster.class,
                p.getBoundingBox().inflate(ultimate ? 7.0 : 3.5), Monster::isAlive)) {
            buff(target, MobEffects.MOVEMENT_SLOWDOWN, ultimate ? 180 : 80, ultimate ? 4 : 1);
            if (ultimate) target.setTicksFrozen(Math.max(target.getTicksFrozen(), 100));
        }
        if (ultimate) strikeNearby(l, p, 6, 8.0F, 1.4, false);
        p.playSound(SoundEvents.BEACON_ACTIVATE, 0.9F, ultimate ? 1.5F : 1.9F);
    }

    private static void tiger(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.MOVEMENT_SPEED, ultimate ? 240 : 140, ultimate ? 3 : 2);
        buff(p, MobEffects.JUMP, ultimate ? 180 : 100, ultimate ? 2 : 1);
        if (ultimate) buff(p, MobEffects.DAMAGE_BOOST, 200, 2);
        launch(p, ultimate ? 1.7 : 1.2, ultimate ? 0.35 : 0.18);
        burst(l, p, ParticleTypes.CRIT, ultimate ? 90 : 36, 0.75);
        strikeNearby(l, p, ultimate ? 6 : 4, ultimate ? 9.0F : 4.0F, ultimate ? 1.8 : 1.0, false);
        p.playSound(SoundEvents.WOLF_GROWL, 1.0F, ultimate ? 0.65F : 1.0F);
    }

    private static void steel(ServerPlayer p, ServerLevel l, boolean ultimate) {
        buff(p, MobEffects.DAMAGE_RESISTANCE, ultimate ? 380 : 200, ultimate ? 2 : 1);
        buff(p, MobEffects.ABSORPTION, ultimate ? 320 : 160, ultimate ? 3 : 1);
        burst(l, p, ParticleTypes.CLOUD, ultimate ? 80 : 30, 0.55);
        strikeNearby(l, p, ultimate ? 7.0 : 3.0, ultimate ? 10.0F : 4.0F, ultimate ? 2.0 : 0.6, false);
        p.playSound(SoundEvents.IRON_GOLEM_REPAIR, 0.9F, ultimate ? 0.7F : 1.0F);
    }

    private static void launch(ServerPlayer player, double forward, double upward) {
        Vec3 look = player.getLookAngle();
        Vec3 horizontal = new Vec3(look.x, 0.0, look.z);
        if (horizontal.lengthSqr() > 1.0E-5) horizontal = horizontal.normalize().scale(forward);
        player.setDeltaMovement(player.getDeltaMovement().multiply(0.25, 0.0, 0.25)
                .add(horizontal).add(0.0, upward, 0.0));
        player.hasImpulse = true;
    }

    private static void fireBolt(ServerPlayer player, ServerLevel level, int count) {
        Vec3 look = player.getLookAngle().normalize();
        for (int i = 0; i < count; i++) {
            double spread = (i - (count - 1) / 2.0) * 0.12;
            Vec3 direction = look.add(-look.z * spread, 0.0, look.x * spread).normalize();
            SmallFireball bolt = new SafeFireball(level, player, direction);
            bolt.setPos(player.getX() + look.x * 0.8, player.getEyeY() - 0.2,
                    player.getZ() + look.z * 0.8);
            level.addFreshEntity(bolt);
        }
    }

    private static void shadowStep(ServerPlayer player, ServerLevel level, boolean ultimate) {
        Monster target = level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(ultimate ? 14 : 9),
                        entity -> entity.isAlive() && player.hasLineOfSight(entity)).stream()
                .min(java.util.Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
        if (target == null) {
            launch(player, ultimate ? 1.5 : 0.9, 0.12);
            return;
        }
        Vec3 towardTarget = target.position().subtract(player.position());
        Vec3 offset = towardTarget.lengthSqr() < 1.0E-5 ? new Vec3(0, 0, 1) : towardTarget.normalize();
        Vec3 destination = target.position().add(offset.scale(1.4));
        if (level.noCollision(player, player.getBoundingBox().move(destination.subtract(player.position())))) {
            player.teleportTo(level, destination.x, destination.y, destination.z, java.util.Set.of(),
                    player.getYRot(), player.getXRot());
            target.hurt(level.damageSources().playerAttack(player), ultimate ? 12.0F : 7.0F);
            target.knockback(ultimate ? 1.1 : 0.6, player.getX() - target.getX(), player.getZ() - target.getZ());
        }
    }

    /** Fire bolts can ignite mobs but deliberately disappear on blocks to avoid world griefing. */
    private static final class SafeFireball extends SmallFireball {
        private SafeFireball(ServerLevel level, LivingEntity owner, Vec3 velocity) {
            super(level, owner, velocity);
        }

        @Override
        protected void onHitBlock(BlockHitResult result) {
            discard();
        }
    }

    private static void buff(LivingEntity player, net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect,
                             int duration, int amplifier) {
        player.addEffect(new MobEffectInstance(effect, duration, amplifier, false, true, true));
    }

    private static void burst(ServerLevel level, ServerPlayer player, net.minecraft.core.particles.ParticleOptions particle,
                              int count, double spread) {
        level.sendParticles(particle, player.getX(), player.getY() + 1.0, player.getZ(), count,
                spread, spread * 0.55, spread, 0.02);
    }

    private static void strikeNearby(ServerLevel level, ServerPlayer player, double radius, float damage,
                                     double knockback, boolean setOnFire) {
        for (Monster target : level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(radius),
                entity -> entity.isAlive())) {
            target.hurt(level.damageSources().playerAttack(player), damage);
            if (setOnFire) target.setSecondsOnFire(4);
            target.knockback(knockback, player.getX() - target.getX(), player.getZ() - target.getZ());
        }
    }
}


