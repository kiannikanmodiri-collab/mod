package com.ageofpower.mod.content;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AgeOfPower.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("item_group.ageofpower.main"))
            .icon(() -> new ItemStack(ModArmor.KIAN_CHESTPLATE.get()))
            .displayItems((parameters, output) -> {
                ModArmor.ITEMS.getEntries().forEach(entry -> output.accept(entry.get()));
                ModItems.ITEMS.getEntries().forEach(entry -> output.accept(entry.get()));
                ModBlocks.ITEMS.getEntries().forEach(entry -> output.accept(entry.get()));
            })
            .build());

    private ModCreativeTabs() {}
}
