package com.ageofpower.mod.content;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Distinct wearable armor sets for the three characters defined in the supplied canon. */
public final class ModArmor {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AgeOfPower.MOD_ID);

    private static final Holder<ArmorMaterial> ZOROASTRIAN = Holder.direct(material("zoroastrian", 2, 7, 5, 2, 25));
    private static final Holder<ArmorMaterial> BLOODY_SKULLS = Holder.direct(material("bloody_skulls", 2, 7, 5, 2, 18));
    private static final Holder<ArmorMaterial> SHAHBAZ = Holder.direct(material("shahbaz", 3, 8, 6, 3, 30));

    public static final RegistryObject<Item> KIAN_HELMET = armor("kian_helmet", ZOROASTRIAN, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> KIAN_CHESTPLATE = armor("kian_chestplate", ZOROASTRIAN, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> KIAN_LEGGINGS = armor("kian_leggings", ZOROASTRIAN, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> KIAN_BOOTS = armor("kian_boots", ZOROASTRIAN, ArmorItem.Type.BOOTS);

    public static final RegistryObject<Item> NIKAN_HELMET = armor("nikan_helmet", BLOODY_SKULLS, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> NIKAN_CHESTPLATE = armor("nikan_chestplate", BLOODY_SKULLS, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> NIKAN_LEGGINGS = armor("nikan_leggings", BLOODY_SKULLS, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> NIKAN_BOOTS = armor("nikan_boots", BLOODY_SKULLS, ArmorItem.Type.BOOTS);

    public static final RegistryObject<Item> SHAHBAZ_HELMET = armor("shahbaz_helmet", SHAHBAZ, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> SHAHBAZ_CHESTPLATE = armor("shahbaz_chestplate", SHAHBAZ, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> SHAHBAZ_LEGGINGS = armor("shahbaz_leggings", SHAHBAZ, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> SHAHBAZ_BOOTS = armor("shahbaz_boots", SHAHBAZ, ArmorItem.Type.BOOTS);

    static {
        // Reference-only costume drafts: their names stay descriptive until Kian provides canon names.
        addSet("lion_warrior", Holder.direct(material("lion_warrior", 3, 8, 7, 3, 30)));
        addSet("eagle_vanguard", Holder.direct(material("eagle_vanguard", 2, 7, 5, 2, 22)));
        addSet("red_dragon", Holder.direct(material("red_dragon", 3, 8, 6, 2, 25)));
        addSet("samurai_guardian", Holder.direct(material("samurai_guardian", 2, 7, 5, 2, 24)));
        addSet("iron_vanguard", Holder.direct(material("iron_vanguard", 3, 8, 6, 2, 24)));
        addSet("sun_champion", Holder.direct(material("sun_champion", 2, 7, 5, 2, 22)));
        addSet("blue_guardian", Holder.direct(material("blue_guardian", 2, 7, 5, 2, 22)));
        addSet("tiger_guardian", Holder.direct(material("tiger_guardian", 2, 7, 5, 2, 22)));
        addSet("steel_sentinel", Holder.direct(material("steel_sentinel", 3, 8, 6, 2, 24)));
    }

    private static void addSet(String name, Holder<ArmorMaterial> material) {
        armor(name + "_helmet", material, ArmorItem.Type.HELMET);
        armor(name + "_chestplate", material, ArmorItem.Type.CHESTPLATE);
        armor(name + "_leggings", material, ArmorItem.Type.LEGGINGS);
        armor(name + "_boots", material, ArmorItem.Type.BOOTS);
    }

    private static RegistryObject<Item> armor(String name, Holder<ArmorMaterial> material, ArmorItem.Type type) {
        return ITEMS.register(name, () -> new ArmorItem(material, type,
                new Item.Properties().durability(type.getDurability(15))));
    }

    private static ArmorMaterial material(String texture, int boots, int leggings, int chest, int helmet, int enchantment) {
        Map<ArmorItem.Type, Integer> defense = new EnumMap<>(ArmorItem.Type.class);
        defense.put(ArmorItem.Type.BOOTS, boots);
        defense.put(ArmorItem.Type.LEGGINGS, leggings);
        defense.put(ArmorItem.Type.CHESTPLATE, chest);
        defense.put(ArmorItem.Type.HELMET, helmet);
        return new ArmorMaterial(defense, enchantment, SoundEvents.ARMOR_EQUIP_IRON,
                () -> Ingredient.of(Items.IRON_INGOT),
                List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(AgeOfPower.MOD_ID, texture))),
                1.0F, 0.05F);
    }

    private ModArmor() {}
}
