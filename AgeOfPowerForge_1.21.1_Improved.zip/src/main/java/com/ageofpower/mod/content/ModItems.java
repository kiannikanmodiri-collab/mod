package com.ageofpower.mod.content;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AgeOfPower.MOD_ID);

    public static final RegistryObject<Item> PARSIAN_INSIGNIA = ITEMS.register("parsian_insignia",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLOODY_SKULLS_INSIGNIA = ITEMS.register("bloody_skulls_insignia",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SHAHBAZ_SWORD = ITEMS.register("shahbaz_sword",
            () -> new SwordItem(Tiers.IRON, new Item.Properties()
                    .attributes(SwordItem.createAttributes(Tiers.IRON, 4, -2.4F)).durability(512)));
    public static final RegistryObject<Item> SHAHBAZ_SHIELD = ITEMS.register("shahbaz_shield",
            () -> new ShieldItem(new Item.Properties().durability(500)));
    public static final RegistryObject<Item> PERSEPOLIS_BLUEPRINT = ITEMS.register("persepolis_blueprint",
            PersepolisBlueprintItem::new);

    public static final RegistryObject<Item> KIAN_POWER_CORE = power("kian_power_core", HeroPowerItem.Profile.KIAN);
    public static final RegistryObject<Item> LION_POWER_CORE = power("lion_power_core", HeroPowerItem.Profile.LION);
    public static final RegistryObject<Item> NIKAN_POWER_CORE = power("nikan_power_core", HeroPowerItem.Profile.NIKAN);
    public static final RegistryObject<Item> SHAHBAZ_POWER_CORE = power("shahbaz_power_core", HeroPowerItem.Profile.SHAHBAZ);
    public static final RegistryObject<Item> EAGLE_POWER_CORE = power("eagle_power_core", HeroPowerItem.Profile.EAGLE);
    public static final RegistryObject<Item> DRAGON_POWER_CORE = power("dragon_power_core", HeroPowerItem.Profile.DRAGON);
    public static final RegistryObject<Item> SAMURAI_POWER_CORE = power("samurai_power_core", HeroPowerItem.Profile.SAMURAI);
    public static final RegistryObject<Item> IRON_VANGUARD_POWER_CORE = power("iron_vanguard_power_core", HeroPowerItem.Profile.IRON_VANGUARD);
    public static final RegistryObject<Item> SUN_CHAMPION_POWER_CORE = power("sun_champion_power_core", HeroPowerItem.Profile.SUN_CHAMPION);
    public static final RegistryObject<Item> BLUE_GUARDIAN_POWER_CORE = power("blue_guardian_power_core", HeroPowerItem.Profile.BLUE_GUARDIAN);
    public static final RegistryObject<Item> TIGER_POWER_CORE = power("tiger_power_core", HeroPowerItem.Profile.TIGER);
    public static final RegistryObject<Item> STEEL_SENTINEL_POWER_CORE = power("steel_sentinel_power_core", HeroPowerItem.Profile.STEEL_SENTINEL);

    private static RegistryObject<Item> power(String name, HeroPowerItem.Profile profile) {
        return ITEMS.register(name, () -> new HeroPowerItem(profile));
    }

    private ModItems() {}
}
