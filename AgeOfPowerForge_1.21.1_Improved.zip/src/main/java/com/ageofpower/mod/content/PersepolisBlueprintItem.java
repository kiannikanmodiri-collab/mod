package com.ageofpower.mod.content;

import com.ageofpower.mod.AgeOfPower;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Places a compact, explorable Persepolis-inspired terrace on a clear, flat area. */
public final class PersepolisBlueprintItem extends Item {
    private static final int FOOTPRINT = 21;
    private static final int HEIGHT = 12;

    public PersepolisBlueprintItem() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (context.getClickedFace() != Direction.UP) {
            if (!level.isClientSide && context.getPlayer() != null) {
                context.getPlayer().displayClientMessage(Component.translatable("message.ageofpower.blueprint.top_face"), true);
            }
            return InteractionResult.FAIL;
        }

        if (!level.isClientSide && context.getPlayer() instanceof ServerPlayer player
                && !player.getAbilities().mayBuild) {
            return fail(context, "message.ageofpower.blueprint.no_permission");
        }

        BlockPos origin = context.getClickedPos().above();
        if (origin.getY() + HEIGHT - 1 >= level.getMaxBuildHeight()) {
            return fail(context, "message.ageofpower.blueprint.height");
        }
        if (!isClear(level, origin)) {
            return fail(context, "message.ageofpower.blueprint.clear_area");
        }

        if (!level.isClientSide) {
            build(level, origin);
            if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private InteractionResult fail(UseOnContext context, String messageKey) {
        if (!context.getLevel().isClientSide && context.getPlayer() != null) {
            context.getPlayer().displayClientMessage(Component.translatable(messageKey), true);
        }
        return InteractionResult.FAIL;
    }

    private boolean isClear(Level level, BlockPos origin) {
        // Refuse unloaded chunks and uneven/occupied terrain before placing anything.
        for (int x = 0; x < FOOTPRINT; x++) {
            for (int z = 0; z < FOOTPRINT; z++) {
                BlockPos ground = origin.below().offset(x - FOOTPRINT / 2, 0, z - FOOTPRINT / 2);
                if (!level.hasChunkAt(ground) || !level.getWorldBorder().isWithinBounds(ground)
                        || !isNaturalFoundation(level.getBlockState(ground))) return false;
            }
        }
        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < FOOTPRINT; x++) {
                for (int z = 0; z < FOOTPRINT; z++) {
                    BlockPos pos = origin.offset(x - FOOTPRINT / 2, y, z - FOOTPRINT / 2);
                    if (!level.hasChunkAt(pos) || !level.getWorldBorder().isWithinBounds(pos)) return false;
                    if (!level.isEmptyBlock(pos)) return false;
                }
            }
        }
        return true;
    }

    private boolean isNaturalFoundation(BlockState state) {
        return state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.DIRT) || state.is(Blocks.COARSE_DIRT)
                || state.is(Blocks.ROOTED_DIRT) || state.is(Blocks.PODZOL) || state.is(Blocks.MYCELIUM)
                || state.is(Blocks.MOSS_BLOCK) || state.is(Blocks.MUD) || state.is(Blocks.CLAY)
                || state.is(Blocks.GRAVEL) || state.is(Blocks.STONE) || state.is(Blocks.ANDESITE)
                || state.is(Blocks.DEEPSLATE) || state.is(Blocks.TUFF) || state.is(Blocks.CALCITE)
                || state.is(Blocks.DRIPSTONE_BLOCK) || state.is(Blocks.SAND) || state.is(Blocks.RED_SAND)
                || state.is(Blocks.SANDSTONE) || state.is(Blocks.RED_SANDSTONE);
    }

    private void build(Level level, BlockPos origin) {
        BlockState sandstone = ModBlocks.PERSEPOLIS_SANDSTONE.get().defaultBlockState();
        BlockState carved = ModBlocks.PERSEPOLIS_CARVED_STONE.get().defaultBlockState();
        BlockState gold = ModBlocks.PERSIAN_GOLD_INLAY.get().defaultBlockState();

        // Four stepped terraces create a broad ceremonial platform.
        fillSquare(level, origin, 0, 20, sandstone);
        fillSquare(level, origin, 1, 16, carved);
        fillSquare(level, origin, 2, 12, sandstone);
        fillSquare(level, origin, 3, 8, carved);

        // Gold floor lines lead to the upper court.
        for (int i = 5; i <= 15; i++) {
            place(level, origin, 3, i, 10, gold);
            place(level, origin, 3, 10, i, gold);
        }

        // Four column bases, fluted shafts, and capitals around the central hall.
        int[][] columns = {{7, 7}, {13, 7}, {7, 13}, {13, 13}};
        for (int[] column : columns) {
            int x = column[0];
            int z = column[1];
            place(level, origin, 4, x, z, gold);
            for (int y = 5; y <= 9; y++) {
                place(level, origin, y, x, z, carved);
                if (y == 7) place(level, origin, y, x + 1, z, gold);
            }
            place(level, origin, 10, x, z, gold);
            place(level, origin, 10, x + 1, z, sandstone);
        }

        // Open audience hall with a central doorway and a decorated roof.
        for (int y = 4; y <= 8; y++) {
            for (int x = 9; x <= 11; x++) {
                for (int z = 9; z <= 11; z++) {
                    boolean doorway = (x == 10 && z == 11 && y <= 6);
                    boolean window = (y >= 6 && (x == 9 || x == 11) && z == 10);
                    if (!doorway && !window) place(level, origin, y, x, z, sandstone);
                }
            }
        }
        for (int x = 8; x <= 12; x++) {
            for (int z = 8; z <= 12; z++) {
                place(level, origin, 9, x, z, (x == 8 || x == 12 || z == 8 || z == 12) ? gold : carved);
            }
        }

        // A five-wide ceremonial stairway extends from the front of the terrace.
        for (int step = 0; step < 4; step++) {
            int z = 20 - step * 3;
            int y = step;
            for (int x = 8; x <= 12; x++) place(level, origin, y, x, z, step % 2 == 0 ? sandstone : carved);
        }
    }

    private void fillSquare(Level level, BlockPos origin, int y, int size, BlockState state) {
        for (int x = 0; x < size; x++) {
            for (int z = 0; z < size; z++) place(level, origin, y, x + (FOOTPRINT - size) / 2,
                    z + (FOOTPRINT - size) / 2, state);
        }
    }

    private void place(Level level, BlockPos origin, int y, int x, int z, BlockState state) {
        BlockPos pos = origin.offset(x - FOOTPRINT / 2, y, z - FOOTPRINT / 2);
        level.setBlock(pos, state, 3);
    }
}


