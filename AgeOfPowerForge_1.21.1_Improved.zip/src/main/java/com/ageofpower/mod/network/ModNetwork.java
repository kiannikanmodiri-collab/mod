package com.ageofpower.mod.network;

import com.ageofpower.mod.AgeOfPower;
import com.ageofpower.mod.content.HeroPowerItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.SimpleChannel;

/** Small authenticated-by-server channel for the two ability key presses. */
public final class ModNetwork {
    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath(AgeOfPower.MOD_ID, "main"))
            .networkProtocolVersion(1)
            .simpleChannel();

    public static void register() {
        CHANNEL.messageBuilder(AbilityKeyPacket.class, 1, PacketFlow.SERVERBOUND)
                .encoder(AbilityKeyPacket::encode)
                .decoder(AbilityKeyPacket::decode)
                .consumerMainThread(AbilityKeyPacket::handle)
                .add();
    }

    public record AbilityKeyPacket(boolean ultimate) {
        private void encode(FriendlyByteBuf buffer) {
            buffer.writeBoolean(ultimate);
        }

        private static AbilityKeyPacket decode(FriendlyByteBuf buffer) {
            return new AbilityKeyPacket(buffer.readBoolean());
        }

        private void handle(CustomPayloadEvent.Context context) {
            context.setPacketHandled(true);
            ServerPlayer player = context.getSender();
            if (player == null) return;
            ItemStack held = player.getMainHandItem();
            if (held.getItem() instanceof HeroPowerItem core) {
                core.activateFromKey(player, ultimate);
            } else {
                player.displayClientMessage(
                        net.minecraft.network.chat.Component.translatable("message.ageofpower.key.need_core"), true);
            }
        }
    }

    private ModNetwork() {}
}
