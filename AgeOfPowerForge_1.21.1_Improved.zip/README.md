# Age of Power — Minecraft Forge 1.21.1

This is the first playable foundation for the Age of Power mod. It targets Minecraft Java 1.21.1 and Forge 52.1.20, using Java 21.

## Included in this foundation

- Wearable, textured four-piece costume sets for Kian, Nikan, Shahbaz, the Lion Warrior, and image-inspired reference heroes.
- Separate Kian, Lion Warrior, Nikan, Shahbaz, and reference-hero power cores. The Sun Champion prototype heals nearby players only when they share the same Minecraft team.
- Primary and ultimate powers. Hold a core and right-click or press **G** for its primary move; hold Shift and right-click or press **H** for its ultimate. Both keys can be rebound in Minecraft's Controls menu.
- A per-character saved energy pool: 100 maximum, 25 energy for a primary move, 75 for an ultimate, and 1 energy restored every 2 game ticks. Primary cooldown is 5 seconds; ultimate cooldown is 30 seconds.
- Persian/English names, a dedicated creative tab, Shahbaz's sword and shield, and three buildable Persepolis-inspired blocks.
- A craftable Persepolis blueprint that places a compact, four-tier ceremonial terrace with a columned audience hall. It only builds on a clear, level 21×21 area over natural ground and consumes one blueprint in Survival.

## Playing this prototype

- Open the **Age of Power** creative tab for outfits, power cores, building blocks, and the blueprint.
- Hold a character's core in the main hand and right-click or press **G** for its primary prototype power. Hold Shift and right-click or press **H** for its ultimate. Rebind either key in Controls → Age of Power. Each kit has its own saved 100-point energy pool; powers cost 25 or 75, recharge 1 point every 2 ticks, and have separate 5-second / 30-second cooldowns.
- To build Persepolis in Survival, craft Persepolis Sandstone from vanilla sandstone, then craft a blueprint from eight Persepolis Sandstone and one paper. Use it on the top of a block over a clear, flat footprint. It checks the world border, build height, loaded chunks, a natural foundation, and that the full structure volume is empty. It does not remove terrain or overwrite blocks in that volume. Foundations may be grass/dirt, common stone types, sand, gravel, clay, mud, moss, or related natural blocks.
- The blueprint respects Adventure mode's `mayBuild` permission. It does not provide a universal claim-protection integration; on servers with land-claim mods, test the blueprint in a permitted area before use.

## Ability status

The supplied canon establishes the characters, organizations, and visual designs, but does not specify most powers. The playable powers in this first build are therefore **prototype proposals** based on the looks and motifs the creator asked us to use. They are marked as prototypes in their item names and must not be treated as confirmed story canon until Kian approves them. Power of Galaxy is not included.

Kian and the Lion Warrior have stronger two-stage prototype kits. Other reference kits are intentionally modest first drafts that can be replaced with the character's confirmed abilities.

The prototypes include actual movement and combat actions as well as temporary buffs: Kian's ward pulse, Nikan's blink strike, aerial and tiger launches, fire bolts, close-range dashes, shockwaves, ally healing, and brief enemy freezing. See [POWER_BALANCE.md](POWER_BALANCE.md) for costs, cooldowns, ranges, durations, and limits, and [LORE_NOTES.md](LORE_NOTES.md) for the boundary between canon and image-based working labels.

## Build

Install a 64-bit JDK 21 and Gradle 8.8, open this folder, and run:

```powershell
gradle build
```

This source ZIP does not include Gradle Wrapper scripts or the wrapper JAR, so use an installed Gradle 8.8. The mod JAR should be produced under `build/libs` after a successful build. Install Forge 1.21.1 in the launcher and put that JAR into the Forge instance's `mods` folder. A JAR is not included, and this source has not been built or tested in-game.

## Not included yet

NPCs, quests, faction reputation, custom character models/animations, and a continuously visible HUD energy bar are planned follow-on work. The current armor uses Minecraft's player model with its own armor textures. The Persepolis build is a compact stylized landmark, not a historically exact reconstruction. The image with the Nazi insignia is not registered as an Age of Power faction because the supplied canon encyclopedia does not identify it; its character/faction and intended role need the creator's confirmation.
