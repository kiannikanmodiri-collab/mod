# Source review fixes

This package contains source-level corrections made after reviewing `AgeOfPowerForge_Source.zip`.

- Energy recharge and cooldown timestamps now use the server overworld clock, so switching dimensions cannot pause or bypass them. Existing dimension-local timestamps are migrated on first activation; stored energy is preserved and old cooldown timestamps are cleared once.
- Persistent ability keys use locale-independent lowercase names, avoiding different saved keys on Turkish and other locale-specific systems.
- The Persepolis blueprint now checks Adventure build permission, world-border bounds, loaded chunks, build height, empty construction volume, and a wider set of natural foundations.
- English and Persian messages were added for the Adventure permission failure.
- English and Persian README build instructions now state that JDK 21 and Gradle 8.8 are required, that this archive does not include the Gradle Wrapper, and that no JAR is included.
- The README documents that generic land-claim protection integration is not provided. Use the blueprint only in a permitted area on protected servers.

## Verification status

JSON syntax and model-to-texture paths were checked after edits. No Gradle Wrapper binaries/scripts or JDK 21 are available in the current environment. An attempt to retrieve official Gradle Wrapper files failed at the network TLS connection, so this package still requires an installed Gradle 8.8 and has not been built or tested in Minecraft. Do not treat this source ZIP as a verified installable JAR.

