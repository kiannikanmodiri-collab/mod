# Prototype powers — review copy

These are playable draft mechanics, not confirmed Age of Power canon. They use the creator's request to make powers fit the visual references. Replace or rename any entry the creator does not approve.

Every power core stores its own energy and cooldown in the player's saved data. Right-click activates the primary move; Shift + right-click activates the ultimate.

| Core | Primary | Ultimate | Visual/role cue |
|---|---|---|---|
| Kian | Asha Aegis: resistance, regeneration, absorption | Faravahar Judgment: stronger defense and a radiant burst against nearby monsters | White/gold Zoroastrian leader design |
| Lion Warrior | King's Roar: close-range knockback and speed | Lionheart Rampage: stronger roar plus a short combat surge | Lion motif and golden armor |
| Nikan | Shadow Veil: vanish in smoke and blink behind a nearby enemy | Dread Pulse: longer-range blink strike with heavier damage | Dark Bloody Skulls visual |
| Shahbaz | Royal Guard: resistance and strength | Sun Shield Sweep: stronger defense and a sweeping burst | Golden mask, sword, and shield |
| Eagle Vanguard | Aerial maneuver: launch forward and upward with a safe descent | Skystrike: stronger aerial launch and combat surge | Eagle motif |
| Red Dragon | Dragon flare: fire resistance and a launched fire bolt | Ember burst: spread of fire bolts and brief ignition | Dragon and red/gold palette |
| Samurai Guardian | Quick guard: forward dash and short-range slash | Blade sweep: longer dash and broader strike | Japan-inspired draft costume |
| Iron Vanguard | Iron resolve: resistance and strength | Heavy strike: broad shockwave and knockback | Soviet-inspired image reference |
| Sun Champion | Solar renewal: speed and regeneration | Radiant strike: healing pulse for nearby allies and enemies struck | Tricolor/sun reference |
| Blue Guardian | Blue aegis: resistance and slow falling | Aegis burst: briefly slows nearby enemies and freezes them | Blue/white reference |
| Tiger Guardian | Tiger dash: forward leap, speed, and jump | Pouncing strike: stronger leap and close-range damage | South Korean tiger reference |
| Steel Sentinel | Steel shell: resistance and absorption | Heavy strike: area damage and strong knockback | Red/blue armored reference |

Balancing for all prototypes: 100 energy, 25 for a primary move, 75 for an ultimate; energy regenerates at 1 point every 2 ticks. Primary moves cool down for 100 ticks (5 seconds); ultimates cool down for 600 ticks (30 seconds).
